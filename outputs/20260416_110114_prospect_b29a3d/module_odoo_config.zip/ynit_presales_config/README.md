# Presales Config — Prospect

Module généré automatiquement le 16/04/2026.

## Modules installés

- `crm`
- `sale_management`
- `purchase`
- `account_accountant`
- `stock`
- `mrp`

## Paramètres activés

- `group_discount_per_so_line` = `True`
- `module_sale_margin` = `True`
- `default_invoice_policy` = `order`
- `module_stock_dropshipping` = `True`
- `module_account_accountant` = `True`
- `group_stock_multi_locations` = `True`
- `group_stock_adv_location` = `True`
- `replenish_on_order` = `True`
- `group_product_variant` = `True`
- `group_mrp_byproducts` = `True`

## Notes

- Plan comptable PCG France à configurer manuellement
- Comptabilité analytique (1 axe) à paramétrer
- SEPA et TVA intracommunautaire à configurer
- Règles de putaway à définir pour les emplacements multiples
- Plus de 200 kits de vente à créer avec nomenclatures
- Migration de plus de 20 000 clients et 15 000 produits à planifier

## Avertissements

- ⚠️ Volume important de données à migrer (>20k clients, >15k produits)
- ⚠️ Kits avec explosion sur BL nécessite configuration avancée des nomenclatures
- ⚠️ Variantes produits avec matrice incomplète peut nécessiter nettoyage des données
