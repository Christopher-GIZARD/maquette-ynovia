# -*- coding: utf-8 -*-
# Module généré automatiquement par Ynov'iT Presales Pipeline
# Date : 16/04/2026
# Prospect : Prospect

{
    'name': "Presales Config \u2014 Soci\u00e9t\u00e9 88888",
    'version': '19.0.1.0.0',
    'category': 'Tools',
    'summary': "Configuration automatique avant-vente",
    'depends': ["base", "sale_management", "purchase", "account_accountant", "stock", "mrp"],
    'data': ["data/config.xml"],
    'installable': True,
    'auto_install': False,
}
