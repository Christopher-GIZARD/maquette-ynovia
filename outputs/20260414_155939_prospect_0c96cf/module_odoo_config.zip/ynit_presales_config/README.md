# Presales Config — Prospect

Module généré automatiquement le 14/04/2026.

## Modules installés

- `sale`
- `sale_management`

## Paramètres activés

- `group_sale_order_template` = `True`
- `group_product_variant` = `True`
- `group_uom` = `True`

## Notes

- Module généré automatiquement par le pipeline avant-vente.
- À vérifier et ajuster après les ateliers de cadrage.
