# -*- coding: utf-8 -*-
# Module généré automatiquement par Ynov'iT Presales Pipeline
# Date : 14/04/2026
# Prospect : Prospect

{
    'name': "Configuration Avant-Vente",
    'version': '19.0.1.0.0',
    'category': 'Tools',
    'summary': "",
    'depends': ["base", "sale", "sale_management"],
    'data': ["data/res_config_settings.xml"],
    'installable': True,
    'auto_install': False,
}
