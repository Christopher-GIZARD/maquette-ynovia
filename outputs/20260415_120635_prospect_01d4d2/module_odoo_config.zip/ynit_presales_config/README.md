# Presales Config — Prospect

Module généré automatiquement le 15/04/2026.

## Modules installés

- `account_accountant`
- `crm`
- `mrp`
- `purchase`
- `sale`
- `sale_management`

## Paramètres activés

- `group_sale_order_template` = `True`
- `group_product_variant` = `True`
- `group_uom` = `True`
- `group_purchase_order_template` = `True`

## Notes

- Module généré automatiquement par le pipeline avant-vente.
- À vérifier et ajuster après les ateliers de cadrage.
