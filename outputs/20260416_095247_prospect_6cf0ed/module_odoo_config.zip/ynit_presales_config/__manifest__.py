# -*- coding: utf-8 -*-
# Module généré automatiquement par Ynov'iT Presales Pipeline
# Date : 16/04/2026
# Prospect : Prospect

{
    'name': "Configuration Avant-Vente",
    'version': '19.0.1.0.0',
    'category': 'Tools',
    'summary': "",
    'depends': ["base", "crm"],
    'data': ["data/res_config_settings.xml"],
    'installable': True,
    'auto_install': False,
}
