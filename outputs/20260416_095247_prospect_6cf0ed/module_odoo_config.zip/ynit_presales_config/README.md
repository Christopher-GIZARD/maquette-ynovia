# Presales Config — Prospect

Module généré automatiquement le 16/04/2026.

## Modules installés

- `crm`

## Notes

- Module généré automatiquement par le pipeline avant-vente.
- À vérifier et ajuster après les ateliers de cadrage.
